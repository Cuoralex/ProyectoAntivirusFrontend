export default function AboutUsPage() {
  return <div>Nosotros</div>;
}
