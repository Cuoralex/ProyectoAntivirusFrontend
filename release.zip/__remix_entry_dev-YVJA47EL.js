import "/build/_shared/chunk-PNG5AS42.js";

// node_modules/@remix-run/dev/dist/config/defaults/entry.dev.ts
var entry_dev_default = () => {
  import("/build/_shared/react-EAI2LDIX.js");
  import("/build/_shared/jsx-dev-runtime-AMSG5B5Y.js");
  import("/build/_shared/jsx-runtime-O5SBAOHY.js");
  import("/build/_shared/react-dom-BNZYXLBA.js");
  import("/build/_shared/client-5SMAFQUD.js");
  import("/build/_shared/runtime-GC7QIU56.js");
  import("/build/_shared/esm-6CBZ7ML7.js");
  import("/build/_shared/remix_hmr-GQWYW66N.js");
};
export {
  entry_dev_default as default
};
//# sourceMappingURL=/build/__remix_entry_dev-YVJA47EL.js.map
