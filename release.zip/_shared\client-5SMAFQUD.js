import {
  require_client
} from "/build/_shared/chunk-O4BRYNJ4.js";
import "/build/_shared/chunk-U4FRFQSK.js";
import "/build/_shared/chunk-7M6SC7J5.js";
import "/build/_shared/chunk-PNG5AS42.js";
export default require_client();
//# sourceMappingURL=/build/_shared/client-5SMAFQUD.js.map
