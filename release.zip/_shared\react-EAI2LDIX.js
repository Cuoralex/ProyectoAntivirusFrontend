import {
  require_react
} from "/build/_shared/chunk-7M6SC7J5.js";
import "/build/_shared/chunk-PNG5AS42.js";
export default require_react();
//# sourceMappingURL=/build/_shared/react-EAI2LDIX.js.map
