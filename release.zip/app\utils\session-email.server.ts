import { createCookie } from "@remix-run/node";

export const userEmail = createCookie("userEmail");
