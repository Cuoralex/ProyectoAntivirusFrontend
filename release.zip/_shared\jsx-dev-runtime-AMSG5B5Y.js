import {
  require_jsx_dev_runtime
} from "/build/_shared/chunk-XGOTYLZ5.js";
import "/build/_shared/chunk-7M6SC7J5.js";
import "/build/_shared/chunk-PNG5AS42.js";
export default require_jsx_dev_runtime();
//# sourceMappingURL=/build/_shared/jsx-dev-runtime-AMSG5B5Y.js.map
