import Dashboard from "~/components/organisms/dashboard/dashboard";

export default function Profile() {
  return <Dashboard />;
}
