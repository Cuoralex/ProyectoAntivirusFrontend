import {
  require_runtime
} from "/build/_shared/chunk-UWV35TSL.js";
import "/build/_shared/chunk-PNG5AS42.js";
export default require_runtime();
//# sourceMappingURL=/build/_shared/runtime-GC7QIU56.js.map
